//
//  main.m
//  PreOpEval2
//
//  Created by Ashley Kang on 7/29/14.
//  Copyright (c) 2014 kangh. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
